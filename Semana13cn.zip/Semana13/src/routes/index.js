const Product = require('./../model/product');


const express = require('express');
const product = require('./../model/product');
const router = express.Router();

router.get('/',(req, res) => {res.render('index.hbs')});
router.get('/Signin',(req, res) => {res.render('login.hbs')});
router.get('/Signup',(req, res) => {res.render('users/Signup.hbs')});
router.get('/listaUsuarios',(req, res) => {res.render('listaUsuarios.hbs')});
router.get('/listap',(req, res) => {res.render('products/listaproductos.hbs',);

});


module.exports = router;
