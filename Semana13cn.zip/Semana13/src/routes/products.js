const express = require('express');
const router = express.Router();
const Product = require('./../model/product');

router.get('/listap', async(req, res) =>{
    const products = await Product.find({}).lean();
    res.render('/listap', {products});
});
router.get('/products/agregarProducto',(req,res)=>{
    res.render('products/agregarProducto');
});

router.post('/products/agregarProducto', async (req,res)=>{
    const{_id, nombreProducto, descripcion, precio, cantidad}= req.body;
    console.log(req.body);
    const errors = [];

    if(!nombreProducto){
        errors.push(
            {text:'Falta nombre'}
        )
    }

    if(errors.length > 0){
        req.flash('successMessage',errors);
        res.render ('/products/agregarProducto');

    }else{
        //create
        const newProduct = new Product({_id, nombreProducto, descripcion, precio, cantidad});
        console.log(newProduct);

        await newProduct.save(); //Guardar en la coleccion dentro de la BD
        req.flash('successMessage', 'Producto agregado correctamente');
        res.redirect('/listap');


    }
});

module.exports = router;