const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Crud',{

    useCreateIndex: true,
    useNewUrlParser: true,
    useFindAndModify: false,
    useUnifiedTopology: true

}).then(db=> console.log('Server started'));

